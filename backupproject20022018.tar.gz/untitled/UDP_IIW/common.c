#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#define SERVPORT 5194
#include "data_types.h"

void print_information(char *str) {

	fprintf(stdout, "INFO : %s\n", str);
}

void exit_on_error(char *str)
{
	puts("####################  ERROR  ####################\n\n");
    perror(str);
	puts("\n\n#################################################\n\n");
    exit(EXIT_FAILURE);
}


int convert_in_int(char* str)
{
	int v;
	char* p;
	errno =0 ;
	
	print_information(str);
	
	v = strtol(str,&p,0);
	
	if((errno != 0) || (*p != '\0'))
		return -1;
	return v;
}




int open_file(char* filename,int flags)
{
	int fd;
	if((fd = open(filename, flags)) == -1){
		exit_on_error("OPENING FILE");
	}
	return fd;

}


void close_file(int fd)
{
	if(close(fd) == -1)
		exit_on_error("CLOSING FILE");
}




char* read_from_stdin()
{
	char* line = malloc(MAXLINE*sizeof(char));
	if(line == NULL)
		exit_on_error("MALLOC() LINE");
	line = fgets(line,MAXLINE,stdin);
	if(line == NULL){
		if(errno == EINTR)
			print_information("ERRNO == EINTR");
		if(feof(stdin))
			return NULL;
		exit_on_error("FGETS()");
	}
	if(line[strlen(line) - 1] == '\n')
		line[strlen(line) - 1] = '\0';
	return line;
}



off_t get_file_len(int fd)
{
	off_t len = lseek(fd,0,SEEK_END);		//get n. bytes file
	if(len == -1)
		exit_on_error("LSEEK()");

	if(lseek(fd,0,SEEK_SET)  == -1)
		exit_on_error("LSEEK()");

	return len;
}



int generate_casual()
{
    int x = random()%1000 + 1;      //number between 1 and 1000
    return x;
}


void initialize_addr(struct sockaddr_in* s)
{
	 struct sockaddr_in addr = *s;
	 memset((void *)&addr, 0, sizeof(addr));
	 addr.sin_family = AF_INET;
	 addr.sin_addr.s_addr = htonl(INADDR_ANY);
	 addr.sin_port = htons(SERVPORT);
	 *s = addr;

}




char* write_pathname(int len,const char*path,char*filename) {

	char* buffer = malloc(len*sizeof(char));

	if(buffer == NULL)
		exit_on_error("MALLOC() CHAR BUFFER 'PATH NAME'");

	unsigned int h;

	for(h=0;h<strlen(path);h++)
		*(buffer+h) = *(path+h);


	unsigned int k;

	for(k=0;k<strlen(filename);h++,k++)
		*(buffer + h ) = *(filename + k);

	*(buffer + h) = '\0';
	return buffer;
}





char* get_file_path(char* filename,const char* directory) {
	int path = strlen(directory);
	int name = strlen(filename);
    char* new_path = write_pathname(path + name + 1,directory,filename);
	return new_path;
}






int existing_file(char* filename,const char* directory) {

	char* new_path = get_file_path(filename,directory);

	if(access(new_path,F_OK)!= 0)			/*not existing file*/
	   return 0;
	return 1;
}



int get_n_packets(off_t len){

	int packets;

	if((len%MAXLINE) == 0)
		packets = len/MAXLINE;
	else
		packets = (len/MAXLINE) + 1;
	return packets;
}





off_t conv_in_off_t(char data[]) {
	off_t ret;
	char* p;
	unsigned int v;


	errno = 0;
	v = strtoul(data,&p,0);

	if(errno != 0 || *p != '\0')
		exit_on_error("STRTOUL() CONVERT DATA[] TO OFF_T TYPE");

	ret = v;


	return ret;
}


int read_file(char* buffer,int fd,int max_bytes) {
	int r,tot = 0;
	for(;;){
		if(tot == max_bytes)
			break;
		r = read(fd,buffer+tot,max_bytes-tot);
		if(r == -1)
			exit_on_error("READ FILE()");
		if(r == 0)
			break;
		tot += r;
	}
	return tot;
}


void write_file(char buffer[],int fd, int n_bytes)
{
	int v,tot = 0;

	for(;;){

		if(tot == n_bytes)
			break;

		v = write(fd,buffer+tot,n_bytes-tot);
		if(v == -1)
			exit_on_error("ERROR WHILE WRITING ON FILE");

		tot+=v;
	}
}





int get_n_bytes(off_t len,int tot_read)
{
	int n_bytes;
	if(len-tot_read < MAXLINE)
		n_bytes = len - tot_read;
	else
		n_bytes = MAXLINE;

	return n_bytes;
}


void copy_data(char dest[],char* src, int n_bytes)
{
	int i,k=0;

	for(i = 0; i < n_bytes; i++,k++){
		dest[k] = src[i];
	}
}

void write_file_len(off_t* len,int* fd,Packet* p, char* filename,const char* directory)
{
	char* file_path = get_file_path(filename,directory);
	*fd = open_file(file_path,O_RDONLY);
	*len = get_file_len(*fd);
	sprintf(p->payload,"%zu",*len);
}


void initialize_fold(const char* directory) //se servDir non esiste la creo nella cartella corrente del programma ed anche list_file.txt
{
	struct stat st = {0};

	if (stat(directory, &st) == -1){ //se non c'è la creo

		if(mkdir(directory, 0700) == -1)
			exit_on_error("MKDIR COMMAND");
	}
	return;
}


int create_file(char* filename,const char* directory) //scarica  file, se tutto bene ritorna 0 e il file è chiuso, senno -1; va passato l'ack attuale  della comunicazione
{
	int fd;
	char* new_path;

	new_path = get_file_path(filename,directory);
	initialize_fold(directory);

	fd = open(new_path, O_CREAT | O_EXCL | O_WRONLY,0733);
	if (fd == -1) {
		if(errno == EEXIST){
			return -1;
		}
		else
			exit_on_error("OPEN FILE");
	}else{
		fflush(stdout);
	}
	return fd;
}

int lock_file(int fd, int cmd)
{
	int lock;
	struct flock fl;
	fl.l_whence = SEEK_SET;
	fl.l_start = 0;
	fl.l_len = 0;
	fl.l_type = (cmd == LOCK_EX ? F_WRLCK :
		     (cmd == LOCK_SH ? F_RDLCK : F_UNLCK));


	lock =fcntl(fd, F_SETLKW, &fl);
	if(lock == -1)
		exit_on_error("ERROR DURING FCNTL()");
	return lock;
}


int is_file_locked(int fd)
{
	struct flock fd_lock = {F_RDLCK, SEEK_SET,   0,      0,     0 };
	if(fcntl(fd, F_GETLK, &fd_lock) == -1) {
		exit_on_error("ERROR DURING FCNTL()");
	}
	if(fd_lock.l_type == F_UNLCK)
		return 0;
	return 1;
}




