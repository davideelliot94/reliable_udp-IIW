#include "basic.h"
#include "configurations.h"
#include "data_types.h"
#include "common.h"
#include "thread_functions.h"
#include "timer_functions.h"
#include "packet_functions.h"
#include "window_operations.h"


extern int n_win;
int adaptive;


void pSigHandler(int sign)
{
	(void)sign;
	int status;
	pid_t pid;

	while ((pid = waitpid(WAIT_ANY, &status, WNOHANG)) > 0);
	return;
}


void initialize_sem(struct sigaction *s)
{
    s->sa_handler = pSigHandler;
    s->sa_flags = SA_RESTART;
    sigemptyset(&s->sa_mask);

    if (sigaction(SIGCHLD, s, NULL) == -1) {
        exit_on_error("ERROR DURING SIGACTION");
    }
}

void startup_socket(int* sockfd,struct sockaddr_in* sockaddr)
{
	int fd;
	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		exit_on_error("ERROR GETTING SOCKET FILE DESCRIPTOR");

	if (bind(fd, (struct sockaddr *)sockaddr, sizeof(*sockfd)) < 0)
		exit_on_error("ERROR IN BIND");
	*sockfd = fd;
}


int get_queue()
{
	key_t key = ftok(".",'b');
	if(key == -1)
		exit_on_error("ERROR GETTING KEY FOR QUEQUE");
	int q = msgget(key,IPC_CREAT |  0666);
	if(q == -1)
		exit_on_error("ERROR GETTING MESSAGE QUEQUE");
	return q;
}

CheckProcStruct* get_current_shmem(int shm_id)
{
    CheckProcStruct* cps = shmat(shm_id,NULL,0);
    if(cps == (void*) -1)
        exit_on_error("ERROR DURING SHMGET");
    return cps;
}

CheckProcStruct* get_shmem(int* shm_id)
{
	key_t key = ftok(".",'1');
	if(key == -1)
		exit_on_error("ERROR DURING FTOK()");
	int id = shmget(key,sizeof(CheckProcStruct),IPC_CREAT | 0666);
	if(id == -1)
		exit_on_error("ERROR GETTING SHMEM ID");
	CheckProcStruct* p = shmat(id,NULL,0);
	if(p == (void*) -1)
		exit_on_error("ERROR DURING SHMAT()");
    if(sem_init(&p->sem,1,1) == -1)
        exit_on_error("ERROR INITIALIZING SEMAPHORE");
    p->free_proc_num = 10;
	*shm_id = id;//initial number of processes
	return p;
}


void main_task(int sockfd,Packet* p,struct sockaddr_in* addr,socklen_t* len)
{
    struct sockaddr_in servaddr = *addr;
    socklen_t l = *len;
    l = sizeof(servaddr);
    print_information("LISTENING REQUEST");

    if((recvfrom(sockfd, p, sizeof(Packet), 0, (struct sockaddr *)&servaddr, &l)) < 0)
         exit_on_error("ERROR WHILE RECEIVING PACKETS");

    *addr = servaddr;
    *len = l;
    return;
}


void send_file(char comm[],int sockfd,Packet p,struct sockaddr_in servaddr)
{
	int n_ack_received = 0,next_ack,i = 0;
	int fd = -1;
	struct thread_data td;
	int end_seq = 0,win_ind,start_seq = p.header.num_seq;
	Packet recv_h;
	Window* w = NULL;
	struct timespec arrived;

	initialize_window(&w,'s');

	w->pack[w->E].header.num_ack = start_seq;
	send_ack(sockfd,w->pack[w->E],servaddr,COMMAND_LOSS,p.header.num_seq);			/*send ack for command*/
	w->pack[w->E].header.flag = 1;
	w->E = (w->E + 1)%(n_win + 1);
	int tmp = start_seq;


	if(!receive_ack(w,sockfd,servaddr,&recv_h,p.header.num_seq,'s',0)){
		print_information("CLIENT IS NOT RESPONDING, TASK CANNOT BE EXECUTED");
		return;
	}

	w->pack[w->S].header.flag = 2;
	increase_window(w);


	int existing = 1;
	if(strncmp(comm,"get",3)== 0)
    {							/*get file*/
		if(!existing_file(comm+4,"./serverDir/")){
			print_information("FILE NOT EXISTING, BAD REQUEST");
			existing = 0;
		}
		else
        {
			char* new_path = get_file_path(comm+4,"./serverDir/");
			fd = open_file(new_path,O_RDONLY);
			if(is_file_locked(fd))
				existing = 0;
		}

	}
	else
    {
		char* new_path = get_file_path("list_file.txt","./serverDir/");					/*get file on server directory*/
		fd = open_file(new_path,O_RDONLY);
		if(lock_file(fd,LOCK_SH) == -1)
				exit_on_error("ERROR WHILE LOCKING FILE");
	}

	off_t len = 0;
	if(existing){
		len = get_file_len(fd);
		sprintf(p.payload,"%zu",len);
	}
	else
		p.payload[0] = '\0';					/*if file is locked or not exists, server send data with '\0'
											in first position*/

	insert_in_window(w,p.payload,tmp + 1,strlen(p.payload));
	send_packet(sockfd,servaddr,&(w->pack[w->E]),COMMAND_LOSS);			/*send size file*/
	w->E = (w->E + 1)%(n_win + 1);


	if(!receive_ack(w,sockfd,servaddr,&recv_h,tmp + 1,'s',0)){
		print_information("CLIENT NOT RESPONDING, TASK CANNOT BE EXECUTED");
		return;
	}

	if(p.payload[0] == '\0')
		return;

	w->pack[w->S].header.flag = 2;
	increase_window(w);

	int tot_read = 0,n_packets = get_n_packets(len);


	for(i = 0; i < n_win; i++){
		read_and_insert(w,len,&tot_read,fd,start_seq + i + 2);
		end_seq = w->pack[w->E].header.num_seq + 1;
		send_packet(sockfd,servaddr,&(w->pack[w->E]),PACKET_LOSS);

		w->E = (w->E + 1)%(n_win+1);
		if(tot_read >= len)
			break;
	}

	start_thread(td,servaddr,sockfd,w);				//start thread for retransmitting expired packets*/
	next_ack = w->pack[w->S].header.num_seq;

	for(;;)
    {

		if(n_ack_received == n_packets)
			break;

		if(!receive_packet(sockfd,&p,&servaddr)){		//if no packets arrived, request terminates with error
			if(tot_read == len)
				print_information("FILE SENT SUCCESFULLY, BUT NO RESPONSE WAS RECEIVED, FILE COULD BE CORRUPTED");
			else
				print_information("CLIENT NOT RESPONDING, TASK WILL BE TERMINATED");
			return;
		}

		win_ind = (p.header.num_ack-start_seq)%(n_win + 1);

		if(p.header.num_ack<next_ack || (w->pack[win_ind].header.flag == 2))
			continue;

		mutex_lock(&w->tobuff);
		w->pack[win_ind].header.flag = 2;				/*received ack*/
		mutex_unlock(&w->tobuff);


		if(adaptive == 1){
			start_timer(&arrived);
			calculate_timeout(arrived,w->pack[win_ind].header.tstart);
		}

		next_ack = next_ack + increase_window(w);
		++n_ack_received;

		if(tot_read>=len)
			continue;

		int nE = (w->E + 1)%(n_win + 1);

		while(nE != w->S){											/*window not full*/
			read_and_insert(w,len,&tot_read,fd,start_seq + i + 2);
			send_packet(sockfd,servaddr,&(w->pack[w->E]),PACKET_LOSS);

			if(tot_read == len){
				end_seq = w->pack[w->E].header.num_seq + 1;
			}

			w->E = nE;
			nE = (nE + 1)%(n_win + 1);
			++i;

			if(tot_read == len){
				break;
			}
		}
	}

	w->end = 1;


	/*
	 * after received all ack, server sends message to close connection and wait for client ack;
	 * if no data received for at most 10 times, request terminates
	 */

	if(!wait_ack(sockfd,servaddr,p,end_seq)){
		print_information("FILE SENT SUCCESFULLY, BUT CLIENT IS NOT RESPONDING");
		return;
	}

	close_file(fd);
	free(w->pack);
	free(w);


	print_information("FILE SENT SUCCESFULLY");

}







void receive_file(char comm[],int sockfd,Packet p,struct sockaddr_in servaddr)
{
	int fd, i=0, n_pkt,start_seq,win_ind,expected_ack;
	int existing = 0;
	struct timespec t_start = {0,0};
	clock_gettime(CLOCK_MONOTONIC_RAW,&t_start);

	start_seq = p.header.num_seq;
	fd = create_file(comm+4,"./serverDir/");		//tries creating file; if already exists, return -1
	if(fd == -1)
		print_information("THIS FILE IS ALREADY IN SERVER DIRECTORY");


	/*server get a write lock for file; in this way, other client cannot get file before end
	 * write
	 */
	else{
		if(lock_file(fd,LOCK_EX) == -1)
			exit_on_error("ERROR WHILE LOCKING FILE");
	}
	Window* w = NULL;

	initialize_window(&w,'r');					//set every position of window as free
	win_ind = (p.header.num_seq - start_seq)%(n_win);
	set_buffered(w,win_ind,p.header.num_seq);			//save command in window

	increase_receive_win(w);


	if(fd == -1)
    {
		existing = 1;
		set_existing(&p);				//if file exists, server writes character '.' on data
	}

	send_ack(sockfd,p,servaddr,COMMAND_LOSS,p.header.num_seq);							/*send ack for command*/

	Packet rcv;

	/*server waiting for size file; if not received, tries 10 times to resend it*/
	if(!receive_ack(w,sockfd,servaddr,&rcv,p.header.num_seq + 1,'r',existing)){
		print_information("CLIENT NOT RESPONDING");
		return;
	}


	if(rcv.payload[0] == '.'){			//if file exists, client resend packet with '.' in data
		print_information("ENDING OPERATION");
	    return;
	}

	win_ind = (rcv.header.num_seq - start_seq)%(n_win);
	set_buffered(w,win_ind,rcv.header.num_seq);
	increase_receive_win(w);
	off_t len = conv_in_off_t(rcv.payload);

	send_ack(sockfd,rcv,servaddr,COMMAND_LOSS,rcv.header.num_seq);
	expected_ack = rcv.header.num_seq + 1;

	int tot_read = 0,tot_write = 0;

	for(;;)
    {

		if(tot_write == len)						/*received all packets*/
			break;

		if(!receive_packet(sockfd, &p,&servaddr))
        {
			print_information("CLIENT NOT RESPONDING, CURRENT TASK WILL BE TERMINATED");
			return;
		}

		n_pkt = (p.header.num_seq - start_seq) - 2;
		win_ind = (p.header.num_seq-start_seq)%n_win;


		/*expected ack is first packet sequence that receiver expects to receive*/

		if(p.header.num_seq<expected_ack || w->pack[win_ind].header.flag == 0)
        {
			send_ack(sockfd,p,servaddr,COMMAND_LOSS,p.header.num_seq);			/*lost ack; resend*/
			continue;
		}

		buffering_packet(w,win_ind,len,MAXLINE*n_pkt,p,&tot_read);

		while(w->pack[w->S].header.flag == 0)
        {
			save_packet(w,fd,len,&tot_write);
			++expected_ack;
			increase_receive_win(w);
		}

		send_ack(sockfd,p,servaddr,PACKET_LOSS,p.header.num_seq);		/*send ack for packet*/

		++i;
	}

	waiting(sockfd,servaddr,p,expected_ack);

	struct timespec t_download = {0,0};
	clock_gettime(CLOCK_MONOTONIC_RAW,&t_download);

	long t1 = t_download.tv_sec*(1.0e9) + t_download.tv_nsec;
	long t2 = t_start.tv_sec*(1.0e9) + t_start.tv_nsec;
	printf("ELAPSED TIME %ld n\n",t2-t1);

	if(close(fd) == -1)				 /*lock on file is automatically released with close*/
		exit_on_error("ERROR WHILE CLOSING FILE");

	free(w->pack);
	free(w);
}



/***************************************************************
*Process tries receiving command 10 times; if no data 	       *
*arrived, return. Process compare received command, and execute*
*corresponding operation									   *
****************************************************************/
void manage_client(int fd,struct msgbuf msg)
{
	Packet p;
	struct sockaddr_in servaddr;

    char comm[15];

    int attempts = 0,res;
    for(;;){
    	res = receive_command(fd,comm,&p,(struct sockaddr *)&servaddr);
    	if(res == 1)
    		break;
    	else{
    		++attempts;
    		if(attempts == 10){
    			print_information("CLIENT NOT RESPONDING");
    			return;
    		}
    	}
    }


	if(strncmp(comm, "put", 3) == 0){
		 receive_file(comm,fd,p,msg.s);
	}

	else if(  (strncmp(comm,"list",4) == 0) || (strncmp(comm,"get",3) == 0)  ){
		send_file(comm,fd,p,msg.s);
	}

	print_information("REQUEST EXECUTED");

}




void get_semaphore(sem_t* sem)
{
	if(sem_wait(sem) == -1)
		exit_on_error("ERROR GETTING SEMAPHORE");
}


void release_semaphore(sem_t* sem)
{
	if(sem_post(sem) == -1)
		exit_on_error("ERROR RELEASING SEMAPHORE");
}



/*************************************************************************************************
 * Child process waits on message queue; when father writes on queue, child executes		     *
 * client request. A child process executes 5 request, then terminates.							 *
 *************************************************************************************************/


void c_task(int q_id,int shm_id,pid_t pid)
{

	int executed_tasks = 0;
	(void)pid;
	Packet p;
	struct sockaddr_in addr;
	int fd;
	struct msgbuf msq_queque;

	msq_queque.mtype = 1;
	CheckProcStruct* cps = get_current_shmem(shm_id);

	while(executed_tasks < 5){

		if(msgrcv(q_id,&msq_queque,	sizeof(struct sockaddr_in) + sizeof(int),1,0) == -1)
			exit_on_error("ERROR WHILE RECEIVING PACKETS");

		get_semaphore(&cps->sem);
		--(cps->free_proc_num);
		release_semaphore(&cps->sem);


		memset((void *)&addr,0, sizeof(addr));
		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = htonl(INADDR_ANY);
		addr.sin_port = htons(0);

		startup_socket(&fd,&addr);				//every child process creates a new socket


		p.header.num_seq = -1;
		p.header.num_ack = msq_queque.client_seq;

		if (sendto(fd, &p, sizeof(Packet), 0, (struct sockaddr *)&msq_queque.s, sizeof(msq_queque.s)) < 0)			/*connection ack*/
			exit_on_error("ERROR WHILE SENDING PACKET");

		manage_client(fd,msq_queque);						//execute client request
		++executed_tasks;

		get_semaphore(&cps->sem);
		++(cps->free_proc_num);
		release_semaphore(&cps->sem);
	}

	get_semaphore(&cps->sem);
	--(cps->free_proc_num);
	release_semaphore(&cps->sem);

	exit(EXIT_SUCCESS);
}

void spawn_proc(int q,int s)
{

	pid_t pid;
	int i;
	for(i = 0; i < 10; i++){
		pid = fork();
		if(pid == -1)
			exit_on_error("ERROR SPAWNING NEW PROCESS");
		if(pid == 0)
			c_task(q,s,getpid());//passing queue id and shared memory id to processes
	}

	return;
}

void write_on_queue(int qid,struct sockaddr_in s,Packet p)
{

	 struct msgbuf msg;
	 msg.s = s;
	 msg.client_seq = p.header.num_seq;
	 size_t size = sizeof(struct sockaddr_in) + sizeof(int);
	 msg.mtype = 1;


	if(msgsnd(qid,&msg,size,0) == -1)
		perror("ERROR WHILE SENDING MESSAGE ON QUEQUE");
}





void refill_processes(int q_id, int shm_id)
{
	int i;
	pid_t pid;
	for(i = 0; i<5; i++){
		pid = fork();
		if(pid == -1)
			exit_on_error("ERROR WHILE FORKING PROCESSES");
		if(pid == 0){
			CheckProcStruct* cps = get_current_shmem(shm_id);
            /////FAI QUELLA COSA ALLA CESATI CHE SPACCA
			get_semaphore(&cps->sem);
			++(cps->free_proc_num);
			release_semaphore(&cps->sem);
			c_task(q_id,shm_id,getpid());
		}
	}
}


////////questo si può modificare e fare come l'ho fatto io
void check_main_dir()
{
	struct dirent** filelist;
	int n=scandir("serverDir",&filelist,0,alphasort);
	if(n == -1)
		perror("ERROR WHILE SCANNING SERV DIR");

	int fd = open("./serverDir/list_file.txt", O_RDWR | O_CREAT,0666);

	if(lock_file(fd,LOCK_EX) == -1)
		exit_on_error("ERROR WHILE LOCKING FILE");



	int count;

	for(count = 0; count < n; count++)
    {
		if(strncmp(filelist[count]->d_name,"list_file.txt",13) == 0
                || strcasecmp(filelist[count]->d_name,".")== 0 || strcasecmp(filelist[count]->d_name,"..")== 0 )
        {
            continue;
        }

		write_file(filelist[count]->d_name,fd,strlen(filelist[count]->d_name));
		int w = write(fd, "\n",strlen("\n"));
        if(w == -1)
		   perror("ERROR WHILE WRITING ON FILE");

	}
	close_file(fd);					/*lock is automatically released*/
}



int main(int argc, char **argv)
{
    
     int shm_id,q_id,sockfds;
     socklen_t dimaddr;
     struct sockaddr_in addr;
     Packet p;
     CheckProcStruct * cps = NULL;
     struct sigaction act;


     initialize_sem(&act);					/*handle SIGHCLD to avoid zombie processes*/

     /////da capirne l'utilizzo /////
     if(DIMWIN <= 0)
	      n_win = 80;
     if(DIMWIN > 93)
    	  n_win = 93;
     else
	      n_win = DIMWIN;


     if(ADAPTATIVE != 1)
	      adaptive = 0;
     else
          adaptive = 1;
     srand(time(NULL));
     ///////////////////////////////
     /*
      * Create a message queue where send client data to child processes, in particular
      *  IP and port number memorized in struct sockaddr_in by recvfrom if argument is
      *  not NULL
      */
     q_id = get_queue();


     /*
      * Create shared memory, where set variable with number of available processes, and a semaphore
      */
     cps = get_shmem(&shm_id);

     //create processes and passing memory id and queue id
     spawn_proc(q_id,shm_id);

     initialize_addr(&addr);


     if ((sockfds = socket(AF_INET, SOCK_DGRAM, 0)) < 0)		//create listen socket
         exit_on_error("ERROR DURING SOCKET()");

     if (bind(sockfds, (struct sockaddr *)&addr, sizeof(addr)) < 0)
         exit_on_error("ERROR DURING BIND()");



     for(;;)
     {
	    main_task(sockfds,&p,&addr,&dimaddr);
        check_main_dir();
	    write_on_queue(q_id,addr,p);					//write on queue message client data

	  /*
	   * When number of available processes is less than 5, create other 5 processes
	   */

	  if(cps->free_proc_num <5)
      {
		    print_information("NUM OF FREE PROCESSES IS TO LOW");
	  		refill_processes(q_id,shm_id);
	  }
     }
     argc = argc;
     argv = argv;
     wait(NULL);
     return 0;
}
