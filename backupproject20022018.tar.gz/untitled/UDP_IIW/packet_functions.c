#include <errno.h>
#include <stdio.h>
#include "configurations.h"
#include "basic.h"
#include "common.h"
#include "data_types.h"
#include "timer_functions.h"
#include "window_operations.h"



int receive_packet(int fd,Packet* p,struct sockaddr_in* servaddr)
{
	struct sockaddr_in s = *servaddr;
	socklen_t len = sizeof(s);
	int n,attempts = 0;
	for(;;){
		start_socket_timeout(&fd,0);
		n = recvfrom(fd,p,sizeof(Packet),0,(struct sockaddr*)servaddr,&len);
		if(n == -1){
			if(errno == EWOULDBLOCK){
				print_information("NO DATA RECEIVED YET");
				if(attempts == 10){
					reset_socket_timeout(&fd);
					return 0;
				}
				++attempts;
				continue;
			}
			else
				exit_on_error("ERROR WHILE RECEIVING PACKET");
		}
		else
			break;
	}
	reset_socket_timeout(&fd);

	return 1;
}


void send_packet(int fd,struct sockaddr_in servaddr,Packet* p,int probability)
{
	long x = rand()%100 + 1;

	if(x>probability){
		if(sendto(fd,p,sizeof(Packet), 0, (struct sockaddr *)&servaddr,sizeof(servaddr)) < 0)
			exit_on_error("ERROR WHILE SENDING PACKET");
	}
}





void send_ack(int fd,Packet p,struct sockaddr_in servaddr,int probability,int ack_seq)
{
	p.header.num_seq = -1;
	p.header.num_ack = ack_seq;
	long x = rand()%100 + 1;
	if(x > probability){
		if(sendto(fd,&p,sizeof(Packet),0,(struct sockaddr *)&servaddr,sizeof(servaddr)) < 0)
            exit_on_error("ERROR WHILE SENDING ACK");
	}
}


int receive_cmd_ack(int fd,Packet* p,struct sockaddr_in* servaddr)
{
	struct sockaddr_in s = *servaddr;
	socklen_t len = sizeof(s);
	int n,res = 0;
	start_socket_timeout(&fd,0);
	n = recvfrom(fd,p,sizeof(Packet),0,(struct sockaddr*)servaddr,&len);
	if(n == -1){
		if(errno == EWOULDBLOCK){
			res = 0;
		}
		else
			exit_on_error("ERROR WHILE RECEIVING PACKET");
	}
	else
		res = 1;
	reset_socket_timeout(&fd);

	return res;
}


int receive_command(int fd,char comm[],Packet* p,struct sockaddr* servaddr)
{
	struct sockaddr s = *servaddr;
	socklen_t len = sizeof(s);
	int j = 0,res = 0;

	start_socket_timeout(&fd,0);
    int n = recvfrom(fd, p, sizeof(Packet), 0, (struct sockaddr *)servaddr, &len);
    if(n == -1)
    {
    	if(errno == EWOULDBLOCK)
        {
    		errno = 0;
    		res = 0;
    	}
        else
        	exit_on_error("ERROR WHILE RECEIVING COMMAND");
    }
    else
    {
    	res = 1;
    	while(p->payload[j] != '\0')
        {
    		comm[j] = p->payload[j];
    		++j;
    	}
    	comm[j] = '\0';
    }
    return res;
}


int receive_ack(Window* w,int fd,struct sockaddr_in servaddr,Packet* recv,int seq,char c,int existing)
{
	Packet tosend;
	int attempts = 0;
	for(;;)
    {
		if(attempts == 10)
			return 0;
		print_information("\rWAITING...");
		receive_cmd_ack(fd,recv,&servaddr);
		if(c == 's'){
			if(recv->header.num_ack != seq){
				check_window(w,w->E,fd,servaddr);
				++attempts;
			}
			else
				break;
		}
		else{
			if(recv->header.num_seq != seq){
				if(existing)
					set_existing(&tosend);
				send_ack(fd,tosend,servaddr,COMMAND_LOSS,seq-1);							/*send ack for command*/
				++attempts;
			}
			else
				break;
		}

	}
	return 1;
}



int waiting(int fd,struct sockaddr_in servaddr,Packet p,int expected_ack)
{
	int attempts = 0;
	for(;;){
		receive_cmd_ack(fd,&p,&servaddr);			/*receiving fin ack*/

		if(p.header.num_seq<expected_ack){
			send_ack(fd,p,servaddr,COMMAND_LOSS,p.header.num_seq);
			++attempts;
			if(attempts == 10)
				break;
		}
		else{
			send_ack(fd,p,servaddr,COMMAND_LOSS,p.header.num_seq);
			return 1;
		}
	}
	return 1;
}



int wait_ack(int fd,struct sockaddr_in servaddr,Packet p,int end_seq)
{
	p.payload[0] = '\0';
	p.header.num_seq = end_seq;
	send_packet(fd,servaddr,&p,COMMAND_LOSS);

	for(;;){
		if(!receive_packet(fd,&p,&servaddr))
			return 0;
		if(p.header.num_ack == end_seq)
			break;
	}

	return 1;
}
