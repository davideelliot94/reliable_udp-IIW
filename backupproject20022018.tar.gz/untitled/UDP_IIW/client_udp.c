#include "configurations.h"
#include "basic.h"
#include "data_types.h"
#include "common.h"
#include "thread_functions.h"
#include "timer_functions.h"
#include "packet_functions.h"
#include "window_operations.h"

int n_request = 0;
extern int n_win;
int adaptive;

void sighandler(int sign) {

	(void)sign;
	int status;
	pid_t pid;

	--n_request;
	while ((pid = waitpid(WAIT_ANY, &status, WNOHANG)) > 0);

	return;
}




void handle_sigchild(struct sigaction* s) {

    s->sa_handler = sighandler;
    s->sa_flags = SA_RESTART;
    sigemptyset(&s->sa_mask);

    if (sigaction(SIGCHLD, s, NULL) == -1) {
        exit_on_error("ERROR DURING SIGACTION()");
    }
}





int request_to_server(int fd,Packet* p,struct sockaddr_in* addr)
{
    int n;
    struct sockaddr_in s = *addr;
    struct timespec conn_time = {2,0};
    int attempts = 0;
    socklen_t len = sizeof(s);
    p->header.num_seq = generate_casual();


    /******************************************************************
     * Process tries to connect to server and generates a random int; *
     * timeout on recvfrom is setted; if no response received,        *
     * timeout is increased; if no response for 3 times, process      *
     * returns.                                                       *
     ******************************************************************/


    for(;;){
    	if(sendto(fd, p,sizeof(Packet), 0, (struct sockaddr *)&s,sizeof(s)) < 0)
    		exit_on_error("ERROR WHILE SENDING PACKET");


    	if(setsockopt (fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&conn_time,sizeof(conn_time)) < 0)
    		exit_on_error("ERROR DURING SETSOCKOPT \n");

		n = recvfrom(fd,p,sizeof(Packet),0,(struct sockaddr*)&s,&len);

    	if(n < 0){
    		if(errno == EWOULDBLOCK){
    			print_information("SERVER NOT RESPONDING. TRYING AGAIN\n");

				++attempts;

				if(attempts == 3)
    				break;
    			conn_time.tv_sec += conn_time.tv_sec;
    		}
    		else
    			exit_on_error("ERROR WHILE RECEIVING PACKET");
    	}
    	if(n>0){
    		conn_time.tv_sec = 0;
    		conn_time.tv_nsec = 0;
        	if(setsockopt (fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&conn_time,sizeof(conn_time)) < 0)
        		exit_on_error("ERROR DURING SETSOCKOPT");
    		print_information("CLIENT CONNECTED");
    	    *addr = s;
    	    return 1;
    	}
    }

    return 0;					/*not available server*/
}






void print_list(Window* w, off_t len,int*tot_write) {

	int n_bytes = get_n_bytes(len,*tot_write);

	print_information(w->pack[w->S].payload);

	*tot_write = *tot_write + n_bytes;

}




void get_file_client(int sockfd,char* line, Packet p, struct sockaddr_in servaddr)
{
	int fd = -1, win_ind, i=0, first_seq=p.header.num_ack;
	Packet recvpack,sendpack;
	off_t len;

	if(strncmp(line,"get",3) == 0){
		fd = create_file(line+4,"./clientDir/");
		if(fd == -1){
			print_information("FILE ALREADY EXIST IN YOUR DIRECTORY");
			return;
		}
	}

	Window* w = NULL;
	initialize_window(&w,'r');

	i = 1;
	++first_seq;

	insert_in_window(w,line,first_seq,strlen(line));
	sendpack = w->pack[w->E];
	send_packet(sockfd,servaddr,&(w->pack[w->E]),COMMAND_LOSS);
	w->E = (w->E + 1)%(n_win);

	++i;


	if(!receive_ack(w,sockfd,servaddr,&recvpack,first_seq,'s',0)){
		print_information("SERVER NOT RESPONDING; CANNOT START");
		return;
	}

	int tmp = recvpack.header.num_ack;
	increase_receive_win(w);
	send_ack(sockfd,sendpack,servaddr,COMMAND_LOSS,tmp);			/*send ack*/


	if(!receive_ack(w,sockfd,servaddr,&recvpack,tmp+1,'r',0))
		print_information("CANNOT RECIVE SIZE FILE");


	w->pack[w->S] = recvpack;
	increase_receive_win(w);

	printf("SIZE FILE = %s BYTE\n",recvpack.payload);

	send_ack(sockfd,sendpack,servaddr,COMMAND_LOSS,sendpack.header.num_ack+1);			/*send len ack*/

	if(recvpack.payload[0] == '\0'){
		print_information("NOT EXISTING FILE IN SERVER DIRECTORY");
		return;
	}
	len = conv_in_off_t(recvpack.payload);

	int expected_ack = recvpack.header.num_seq + 1;
	int tot_read = 0,tot_write = 0;
	int n_pkt;

	if(strncmp(line,"list",4) == 0)
		printf("\n\n\n");				/*only to clearly show file to user*/

	for(;;){
		if(strncmp(line,"get",3) == 0)
			print_information("\r EXECUTING DOWNLOAD");

		if(tot_write == len)						/*received all packets*/
			break;

		if(!receive_packet(sockfd, &p,&servaddr)){
			return;
		}

		n_pkt = (p.header.num_seq - first_seq -2);
		win_ind = (p.header.num_seq-first_seq)%n_win;
		w->pack[win_ind].header.num_seq = p.header.num_seq;


		if(p.header.num_seq<expected_ack || w->pack[win_ind].header.flag == 0){

			send_ack(sockfd,p,servaddr,PACKET_LOSS,p.header.num_seq);			/*lost ack; resend*/
			continue;
		}

		buffering_packet(w,win_ind,len,MAXLINE*n_pkt,p,&tot_read);

		while(w->pack[w->S].header.flag == 0){
			if(strncmp(line,"list",4) == 0)
				print_list(w,len,&tot_write);

			else
				save_packet(w,fd,len,&tot_write);

			++expected_ack;
			increase_receive_win(w);
		}
		send_ack(sockfd,p,servaddr,PACKET_LOSS,p.header.num_seq);		/*send ack for packet*/

		++i;
	}

	if(!waiting(sockfd,servaddr,p,expected_ack))
		print_information("COMPLETE DOWNLOAD ---> SERVER IS BUSY");

	else
		print_information("DOWNLOAD COMPLETED!");

	if(fd == -1)
		return;

	close_file(fd);

	free(w->pack);
	free(w);
}


void send_file_client(int sockfd,char* line, Packet p, struct sockaddr_in servaddr)
{
	struct thread_data td;
	int next_ack,n_ack_received = 0,win_ind,end_seq = 0,first_seq=p.header.num_ack;
	int n_packets,fd,tot_read = 0;						/*to avoid warning*/
	int i = 1;
	char* filename = line + 4;
	struct timespec arrived;
	off_t len = 0;
	Packet recv;

	Window* w = NULL;
	initialize_window(&w,'s');

	insert_in_window(w,line,first_seq+i,strlen(line));
	send_packet(sockfd,servaddr,&(w->pack[w->E]),COMMAND_LOSS);
	w->E = (w->E + 1)%(n_win + 1);


	if(!receive_ack(w,sockfd,servaddr,&recv,first_seq+i,'s',0)){
		print_information("NOT RESPONDING SERVER; CANNOT START");
		return;
	}

	w->pack[w->S].header.flag = 2;
	increase_window(w);

	if(recv.payload[0] == '.'){
		print_information("FILE ALREADY EXIST IN SERVER DIRECTORY");
		p.payload[0] = '.';
	}


	else
		write_file_len(&len,&fd,&p,filename,"./clientDir/");

	++i;

	insert_in_window(w,p.payload,first_seq + i,strlen(p.payload));
	send_packet(sockfd,servaddr,&(w->pack[w->E]),COMMAND_LOSS);		/*send file len*/
	w->E = (w->E + 1)%(n_win + 1);


	if(recv.payload[0] == '.')					/*not existing file*/
		return;


	if(!receive_ack(w,sockfd,servaddr,&recv,first_seq + i,'s',0)){
		print_information("SERVER NOT RESPONDING END OF OPERATION");
		return;
	}


	w->pack[w->S].header.flag = 2;
	increase_window(w);

	n_packets = get_n_packets(len);
	for(i = 0; i < n_win; i++){
		read_and_insert(w,len,&tot_read,fd,first_seq + i + 3);
		send_packet(sockfd,servaddr,&(w->pack[w->E]),PACKET_LOSS);
		end_seq = w->pack[w->E].header.num_seq + 1;
		w->E = (w->E + 1)%(n_win+1);
		if(tot_read >= len)
			break;
	}


	start_thread(td,servaddr,sockfd,w);

	next_ack = w->pack[w->S].header.num_seq;

	print_information("SENDING FILE");

	for(;;){
		if(n_ack_received == n_packets)
			break;

		if(!receive_packet(sockfd, &p,&servaddr)){
			if(tot_read == len)
				print_information("NOT ALL RESPONSE RECIVED. OPERATION COULD BE NOT COMPLETED");

			else
				print_information("NOT RESPONSE RECIVED; CANNOT COMPLETE OPERATION\n");
			return;
		}

		win_ind = (p.header.num_ack-first_seq - 1)%(n_win + 1);


		if(p.header.num_ack<next_ack || (w->pack[win_ind].header.flag == 2))
			continue;

		mutex_lock(&w->tobuff);
		w->pack[win_ind].header.flag = 2;				/*received ack*/
		mutex_unlock(&w->tobuff);


		if(adaptive == 1){
			start_timer(&arrived);
			calculate_timeout(arrived,w->pack[win_ind].header.tstart);
		}

		next_ack = next_ack + increase_window(w);
		++n_ack_received;

		if(tot_read>=len){

			continue;
		}

		int nE = (w->E + 1)%(n_win + 1);


		while(nE != w->S){							/*window not full*/
			read_and_insert(w,len,&tot_read,fd,first_seq + i + 3);
			send_packet(sockfd,servaddr,&(w->pack[w->E]),PACKET_LOSS);

			if(tot_read == len){
				end_seq = w->pack[w->E].header.num_seq + 1;
			}
			w->E = nE;
			nE = (nE + 1)%(n_win + 1);

			++i;

			if(tot_read == len){
				break;
			}
		}			/*end while*/
	}		/*end for*/

	p.header.num_seq = end_seq;
	w->end = 1;


	if(!wait_ack(sockfd,servaddr,p,end_seq)){
		print_information("COMPLETE OPERATION ---> SERVER IS BUSY\n");
		return;
	}

	free(w->pack);
	free(w);

	print_information("COMPLETE OPERATION!");

}








int main(int argc, char *argv[]) {

  int   sockfd;
  struct    sockaddr_in   servaddr;
  Packet p;
  struct sigaction act;


  if(DIMWIN <= 0)
	  n_win = 80;
  if(DIMWIN > 93)
	  n_win = 93;
  else
	  n_win = DIMWIN;


  if(ADAPTATIVE != 1)
	  adaptive = 0;
  else
	  adaptive = 1;

  handle_sigchild(&act);


  if (argc < 2) {
    fprintf(stderr, "USAGE: DAYTIME_CLIENT UDP <ADDRESS IP  SERVER>\n");
    exit(1);
  }


  if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { /* crea il socket   */
	  exit_on_error("ERROR DURING SOCKET()");
   }

   memset((void *)&servaddr, 0, sizeof(servaddr));
   servaddr.sin_family = AF_INET;
   servaddr.sin_port = htons(SERVPORT);

   if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0) {
        exit_on_error("ERROR DURING INET_PTON()");
   }


  pid_t pid;
  char* line;

  /*************************************************************
   * father process waits command from standard input; then,   *
   * creates a new process to execute. If CTRL + D received,   *
   * waits all children; then, father terminates.               *
   *************************************************************/



  while(feof(stdin) == 0){
	  //ssize_t len_line;
	  char comm[5];


	  print_information("WRITE A COMMAND:");
	  line = read_from_stdin();


	  if(line == NULL){
		  wait(NULL);
		  print_information("ALL REQUEST ENDED. CLOSING CONNECTION");
		  break;
	  }

	  ++n_request;
	  if(n_request > 5){
		  print_information("TOO MANY REQUEST, TRY TO WAIT");
		  continue;
	  }

	  pid = fork();

	  if(pid != 0)
		  continue;

	  if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { /* create new socket   */
		   exit_on_error("ERROR DURING SOCKET()");
	  }

	  if(!request_to_server(sockfd,&p,&servaddr)){
		  print_information("SERVER NOT AVAILABLE");
		  exit(EXIT_SUCCESS);
	  }

	  strncpy(comm, line, 4);
	  comm[strlen(comm)] = '\0';

	  if(strncmp(comm, "put", 3) == 0){
		  if(!existing_file(line+4,"./clientDir/")){
			  print_information("FILE DOESN'T EXIST");
			  break;
		  }
		  send_file_client(sockfd,line,p,servaddr);
		  break;
	  }

	  else if((strncmp(comm,"get",3) == 0) || (strncmp(comm,"list",4) == 0)){
		  get_file_client(sockfd,line,p,servaddr);
		  break;
	  }


	  else{
	  		puts("USE COMMANDS : \n\t-LIST\n\tGET\n\tPUT\n\tFOLLOWEWD BY VALID FILE NAME\n");
	  		break;
	  }


      }
      print_information("CLOSING CONNECTION");

      exit(EXIT_SUCCESS);
}
