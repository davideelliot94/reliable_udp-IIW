#ifndef DATA_TYPES_H_
#define DATA_TYPES_H_


#define MAXLINE 1460
#include <sys/types.h>
#include <sys/socket.h>
 #include <netinet/in.h>
#include <semaphore.h>
#include <pthread.h>



typedef struct{
	sem_t sem;
	int free_proc_num;
}CheckProcStruct;


typedef struct{
	long long int num_seq;
	long long int num_ack;
	int flag;
	struct timespec tstart;
}packHeader;

typedef struct{

	packHeader header;
	char payload[1460];
}Packet;

struct msgbuf{
	long mtype;
	int client_seq;
	struct sockaddr_in s;
};


typedef struct {
	int S;
	int E;
	int end;
	pthread_mutex_t tobuff;
	Packet *pack;
}Window;


struct thread_data{
	int sockfd;
	struct sockaddr_in servaddr;
	pthread_t tid;
	Window* w;
};


#endif
